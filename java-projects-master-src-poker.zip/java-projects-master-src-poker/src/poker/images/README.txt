Images from https://github.com/hayeah/playing-cards-assets

The images are just format-converted from the public domain images at https://code.google.com/archive/p/vector-playing-cards/
